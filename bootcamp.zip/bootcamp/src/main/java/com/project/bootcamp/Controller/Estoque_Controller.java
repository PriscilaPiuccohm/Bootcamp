package com.project.bootcamp.Controller;

import com.project.bootcamp.Model.Dto.Estoque_DTO;
import com.project.bootcamp.service.estoqueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "/Estoque")

public class Estoque_Controller {

    @Autowired
    private estoqueService service;

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Estoque_DTO> save( @Valid  @RequestBody Estoque_DTO dto) {
        return ResponseEntity.ok(service.save(dto));
    }

    @PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Estoque_DTO> update( @Valid @RequestBody Estoque_DTO dto) {
        return ResponseEntity.ok(dto);
    }

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Estoque_DTO>> findALL() {
        List<Estoque_DTO> lista = new ArrayList<>();
        Estoque_DTO dto = new Estoque_DTO();
        dto.setId((long) 1);
        dto.setName("Maga");
        dto.setPrice(100d);
        dto.setVariacao(10d);
        dto.setDate(LocalDate.now());
        lista.add(dto);
        return ResponseEntity.ok(lista);


    }

    @GetMapping(value = "/{id}")
    public void findById(@PathVariable long id) {

      //  Estoque_DTO dtoSelect = lista.stream().filter(x -> x.getId().compareTo(id) == 0).findFirst().get();
       // return (ResponseEntity.ok(dtoSelect);

    }
}

