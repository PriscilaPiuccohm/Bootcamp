package com.project.bootcamp.service;

import com.project.bootcamp.Model.Dto.Estoque_DTO;
import com.project.bootcamp.Model.estoque;
import org.springframework.stereotype.Service;

@Service
public class estoqueService {
    public estoque save(Estoque_DTO dto) {
    }
}
